import io
import pandas as pd
import requests
if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    url = 'https://raw.githubusercontent.com/jnm-ronquillo/demandas-alimentos-piura-peru/main/data/Proceso_Unico_alimentos_DIC2023.csv'

    df = pd.read_csv(url, sep=',', encoding = "ISO-8859-1")
    
    df['MES'] = df['MES'].astype(str)
    df['YEAR'] = df['MES'].str[:4]
    df['MES'] = df['MES'].str[4:]
    df['FECHA'] = pd.to_datetime(df['YEAR'] + df['MES'], format='%Y%m')

    return df


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
