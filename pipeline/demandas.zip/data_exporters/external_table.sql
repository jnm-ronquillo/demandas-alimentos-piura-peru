-- Docs: https://docs.mage.ai/guides/sql-blocks
CREATE OR REPLACE EXTERNAL TABLE `deproject-420601.csjpiura.external_demandas_alimentos`
OPTIONS (
  format = 'PARQUET',
  uris = ['gs://deproject-420601-csjpiura/demandas_alimentos/YEAR=2023/*.parquet']
);